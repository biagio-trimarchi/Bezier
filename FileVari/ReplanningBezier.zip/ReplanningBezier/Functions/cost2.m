function J = cost2(x, n, d, Cd)
   J = (x-Cd)*(x-Cd)';
end