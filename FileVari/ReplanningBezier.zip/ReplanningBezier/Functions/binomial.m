function b = binomial(x, y)
    b = factorial(x)/(factorial(y)*factorial(x-y));
end